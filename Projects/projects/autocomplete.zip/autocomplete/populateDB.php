<?php
/**
 * Created by PhpStorm.
 * User: 1333612
 * Date: 11/8/2016
 * Time: 1:37 PM
 */
require 'CitiesDAO.php';
$a = new DAO();
$a->readFileToDB();