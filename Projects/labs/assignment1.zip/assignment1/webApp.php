<?php
/**
 * Created by PhpStorm.
 * User: 1333612
 * Date: 10/13/2016
 * Time: 10:22 AM
 */

require 'ActionScrapeModule.php';

/**
 * THE CLASS SUFFERS FROM A ERROR, WHEN THE QUERY IS TOO BIG, THE DATABASE FAILS WITH A 1040 ERROR.
 * Class webApp
 */
class webApp
{
    private $serverName = 'waldo2.dawsoncollege.qc.ca';
    private $user = 'CS1333612';
    private $pass = 'secrefer';
    private $dbName = 'CS1333612';

    /**
     * this function will get the most viewd submitters and return an array of
     * gawk ids.
     * @return array
     */
    function getMostViewdSubmitters()
    {
        $query = "SELECT GAWKID FROM GAWK ORDER BY VIEWS DESC";
        $gawkIds = array();
        try {
            $pdo = new PDO("mysql:host=$this->serverName;dbname=$this->dbName", $this->user, $this->pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo $e->getMessage();
        } finally {
            unset ($pdo);
        }
        foreach ($result as $b) {
            foreach ($b as $key => $gid)
                if (is_numeric($key))
                    array_push($gawkIds, $gid);
        }
        return $gawkIds;
    }

    /**
     * This function will get the descriptions from the DB
     * and return an array of descriptions.
     * @return array
     */
    function findGawksByDescription($term)
    {
        $query = "SELECT * FROM GAWK WHERE DESCRIPTION LIKE ?";
        $allGawks = [];
        try {
            $pdo = new PDO("mysql:host=$this->serverName;dbname=$this->dbName", $this->user, $this->pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->prepare($query);
            $stmt->bindValue(1,'%'.$term.'%');
            $stmt->setFetchMode(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, 'Gawk');

            if($stmt->execute()){
                while($row = $stmt->fetch()){
                    $allGawks [] = $row;
                }

            }

        } catch (PDOException $e) {
            echo $e->getMessage();
        } finally {
            unset ($pdo);
        }

        return $allGawks;
    }

    /**
     * This function gets the Gawk from the db by its id number
     * @param $id
     * @return a Gawk Object
     */
    function getGawkById($id)
    {
        $query = "SELECT * FROM GAWK WHERE GAWKID = ?";
        $gawkFromDb = array();
        $g = new Gawk();
        try {
            $pdo = new PDO("mysql:host=$this->serverName;dbname=$this->dbName", $this->user, $this->pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(1, $id);
            $stmt->execute();
            $result = $stmt->fetchAll();
        } catch (PDOException $e) {
            echo $e->getMessage();
        } finally {
            unset ($pdo);
        }

        foreach ($result as $b) {
            foreach ($b as $key => $gawkElements) {
                //var_dump($b);
                if(is_numeric($key))
                    array_push($gawkFromDb, $gawkElements);

            }
        }
        $g->setTitle($gawkFromDb[1]);
        $g->setLink($gawkFromDb[2]);
        $g->setDescription($gawkFromDb[3]);
        $g->setUserName($gawkFromDb[4]);
        $g->setViews($gawkFromDb[5]);
        return $g;
    }

}