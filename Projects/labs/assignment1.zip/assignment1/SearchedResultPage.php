<html>
<head>
    <title>Toothsome</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
          crossorigin="anonymous">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"
          rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1"
          crossorigin="anonymous">
</head>
<body background="res/bg.jpg">

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="mainScript.php">Toothsome</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="mainScript.php">Home</a></li>
            <li><a href="MostToothed.php">Most Tooothed</a></li>
        </ul>
        <div class="container">
            <div class="row">
                <div class="span12">
                    <form action="SearchedResultPage.php" method='post' id="custom-search-form"
                          class="form-search form-horizontal pull-right">
                        <div class="input-append span12">
                            <input name='search' type="text" class="search-query" placeholder="Search">
                            <button type="submit" class="btn"><i class="fa fa-search" aria-hidden="true"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</nav>
<?php
require 'webApp.php';
$w = new webApp();
$allGawks = array();
$g = new Gawk();

//submitting part.
$searchWord = $_POST['search'];
$searchWord = strip_tags($searchWord);

$allGawks = $w->findGawksByDescription($searchWord);


// Page content
$allGawksLength = count($allGawks);

echo "<div class='container'>";
for ($i = 0; $i < $allGawksLength; $i++) {
    $g = $allGawks[$i];
    $title = $g->getTitle();
    $desc = $g->getDescription();
    $uName = $g->getUserName();
    $link = $g->getLink();
    $views = $g->getViews();
    if ($i % 3 == 0)
        echo "<div class='row'>";
    echo "<div class='col-lag-3 col-md-4 col-xs-4 thumb'>";
    echo "<div class= 'thumbnail'>";
    echo "<p> $title</p>";
    echo "<p> $desc</p>";
    echo "<p>$views</p>";
    echo "<p>$uName</p>";
    echo "<a href=$link class='btn btn-sm btn-default'><span class='glyphicon glyphicon-flash'></span>Link To Recipe</a>";
    echo "</div></div>";
    if ($i % 3 == 2)
        echo "</div>";
}
echo "</div>";
?>
<footer class="container-fluid text-center">
    <p>All data © FoodGawker, 2016</p>
</footer>

</body>
</html>
